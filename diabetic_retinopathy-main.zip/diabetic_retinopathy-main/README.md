# diabetic_retinopathy segmentataion using deep learning

we are focusing on hard excudates

to run this colab file replace the paths with the data you have 

data format should only consists of 
data folder -> it consists of Images and masks folder -->check names same as written
they contain only hard excudates 81 combined images and their masks
thats all you can now put in drive or run locally with changing the paths 
